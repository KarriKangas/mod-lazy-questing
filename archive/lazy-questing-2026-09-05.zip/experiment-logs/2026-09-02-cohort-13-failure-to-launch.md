# Cohort 13: same-target quest piggyback failure to launch

## Verdict

Cohort 13 failed to launch and provides no treatment-versus-control efficacy evidence. The live
server remained on the `planning-safe-hold` configuration with all 80 bots in control and atomic
quest interactions disabled. The online roster was still the invalid Cohort 12 roster, so it was
not eligible to become a fresh Cohort 13 population. Renumber the unchanged same-target piggyback
treatment as Cohort 14 and launch it only with a fresh balanced roster and seed.

## Run metadata

| Field | Value |
| --- | --- |
| Date | 2026-09-02 |
| Cohort | Cohort 13 (failure to launch) |
| Run ID | No Cohort 13 run ID; observed run was `planning-safe-hold` |
| Population | 80 online bots from the retired Cohort 12 guilds |
| Guilds | Cohort 12 Horde (44), Cohort 12 Alliance (45) |
| Experiment arms | 80 control, 0 treatment |
| Configuration | control 100%, assist-only 0%, current 0%; atomic interactions off |
| Code/build | repository `05bd58f`; worldserver SHA-256 `B688270593C23D7E4F58D98A2B341DDEA080D1A66BD9AA903CBAB9FF30D4D6FC` |
| Observation | Safe-hold operational intervals only; zero experimental exposure |
| Exclusions | Entire period excluded because no treatment arm or fresh Cohort 13 roster existed |

## Assignment and exposure integrity

Assignment and exposure integrity failed for an efficacy comparison. Scheduler records contained
80 control bots and zero assist-only/current bots. There was therefore no randomized Cohort 13
split to compare, and the active guilds belonged to the invalid Cohort 12 population.

## Implementation sanity check

The intended treatment did not activate. Atomic scans, candidates, attempts, and successes were
all zero because `LazyQuesting.Assist.AtomicQuestInteractions` was disabled. This was correct for
the safe hold but means Cohort 13 never began.

## Progression and mechanism results

No treatment-versus-control progression, time-to-level, questing, combat, travel, loot, gear,
death, stall, time-window, or class/race-tail result is reportable. A retrospective split of the
old Cohort 12 roster would not repair the missing treatment exposure and remains excluded.

## Decision and next experiment

Record Cohort 13 as a failure to launch. Start Cohort 14 as the same preregistered same-target quest
piggyback test using 80 fresh bots, a new optimally balanced 40/40 seed, an exact Cohort 14 run ID,
and the unchanged 25,200-second endpoint. The first uncertainty remains activation: require at
least ten successful atomic actions and at least 50% attempt conversion before interpreting
leveling-speed differences.
